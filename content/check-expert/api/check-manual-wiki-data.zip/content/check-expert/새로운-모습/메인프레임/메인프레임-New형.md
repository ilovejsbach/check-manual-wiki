---
title: "메인프레임 New형"
description: "메인프레임 New형 사용 설명. 공식 전체 매뉴얼 12-13쪽에서 추출."
tags:
  - "CHECK Expert"
  - "공식 매뉴얼"
  - "메인프레임"
  - "기능"
source: "CHECKPlus_Manual.pdf"
knowledge_id: "check:manual:메인프레임:메인프레임-New형"
aliases:
  - "메인프레임 New형"
source_pages: "12-13"
category: "메인프레임"
---
# 메인프레임 New형

> 출처: `CHECKPlus_Manual.pdf`, PDF 12-13쪽. 검색 가능한 본문과 원문 페이지 이미지를 함께 제공합니다.

메인프레임
10 세계시계
도구아이콘 영역에서 선택하는 세계시계는 원하는 위치 아무데나 옮겨놓을 수 있는 floating 기능을 제공하고 티커바 영역
에 제공하는 시계는 고정된 위치에 제공합니다.
11 통합알리미
시세감시, 뉴스감시, 이벤트감시, 시스템감시의 감시결과가 발생했을때 알림아이콘에 불이 들어오면서 미확인 알림 건수를
표시해줍니다.
알림아이콘을 클릭하면 각 감시조건별 결과를 한눈에 조회할 수 있습니다.
메인프레임 New형
메인프레임 NEW형은 최신 Trend의 새로운 유형을 선호하는 사용자를 대상으로 웹 UI에서 많이 사용하는 세로메뉴
바 형식으로 제공합니다.
가장 기본적인 구성요소만 노출하여 심플함을 강조하였고 메인프레임과 화면이 디폴트 독립된 상태라 멀티모니터

사용시 화면을 원하는 위치에 쉽게 옮길 수 있습니다.

<small>원본 PDF 12쪽</small>

<details class="source-page"><summary>원문 PDF 12쪽 보기</summary>

![메인프레임 New형 원문 PDF 12쪽](assets/manual-pages/page-0012.webp)

</details>

메인프레임 New형 | 13
1 도구아이콘 리스트
Winodws의 시작 아이콘과 유사하게 클릭시에는 다음과 같이 도구메뉴가 팝업됩니다.
2 통합검색
를 클릭하면 와 같이 검색어 입력란이 나타나서 키워드
입력을 통해 통합검색을 실행할 수 있습니다.
3 메뉴 선택
를 선택하면 CHECK 메뉴리스트가 조회됩니다.
검색어를 입력하지 않고 CHECK의 전체 메뉴를 살펴보기 위해서는 해당 버튼을 클릭해서 한 단계씩
찾아 들어가실 수도 있습니다.
4 페이지저장
복수개의 화면을 배치한후 를 클릭하면 확인창 팝업없이 즐겨찾기바에 저장됩니다.
5 즐겨찾기바 ~ 11 통합알리미의 기능은 메인프레임 클래식형의 설명을 참고하시기 바랍니다.

<small>원본 PDF 13쪽</small>

<details class="source-page"><summary>원문 PDF 13쪽 보기</summary>

![메인프레임 New형 원문 PDF 13쪽](assets/manual-pages/page-0013.webp)

</details>
