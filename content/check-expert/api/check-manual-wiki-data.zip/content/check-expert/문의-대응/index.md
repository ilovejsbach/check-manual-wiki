---
title: "문의 대응 지식"
description: "비식별 문의를 질문과 답변·사용 절차·오류 해결·주의사항·활용 팁으로 탐색하는 검수 대기 색인."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "검수 필요"
source: "manual-enrichment.jsonl"
knowledge_id: "check:enrichment:index"
review_status: "candidate"
related_ids:
  - "check:screen:1002"
  - "check:screen:1103"
  - "check:screen:1147"
  - "check:screen:1148"
  - "check:screen:1149"
  - "check:screen:1155"
  - "check:screen:1160"
  - "check:screen:1211"
  - "check:screen:1300"
  - "check:screen:1302"
  - "check:screen:1318"
  - "check:screen:1339"
  - "check:screen:1340"
  - "check:screen:1370"
  - "check:screen:1379"
  - "check:screen:1425"
  - "check:screen:1440"
  - "check:screen:1443"
  - "check:screen:1448"
  - "check:screen:1511"
  - "check:screen:1531"
  - "check:screen:1542"
  - "check:screen:1547"
  - "check:screen:1584"
relationship_types:
  "check:screen:1002": "mentions_title"
  "check:screen:1103": "mentions_title"
  "check:screen:1147": "mentions_title"
  "check:screen:1148": "mentions_title"
  "check:screen:1149": "mentions_title"
  "check:screen:1155": "mentions_title"
  "check:screen:1160": "mentions_title"
  "check:screen:1211": "mentions_title"
  "check:screen:1300": "mentions_title"
  "check:screen:1302": "mentions_title"
  "check:screen:1318": "mentions_title"
  "check:screen:1339": "mentions_title"
  "check:screen:1340": "mentions_title"
  "check:screen:1370": "mentions_title"
  "check:screen:1379": "mentions_title"
  "check:screen:1425": "mentions_title"
  "check:screen:1440": "mentions_title"
  "check:screen:1443": "mentions_title"
  "check:screen:1448": "mentions_title"
  "check:screen:1511": "mentions_title"
  "check:screen:1531": "mentions_title"
  "check:screen:1542": "mentions_title"
  "check:screen:1547": "mentions_title"
  "check:screen:1584": "mentions_title"
---
# 문의 대응 지식

문의 사례를 화면별 한 묶음으로만 보지 않고 질문과 답변·사용 절차·오류 해결·주의사항·활용 팁으로 분리했습니다. 모든 항목은 공식 매뉴얼과 실제 동작 검증 전까지 `candidate` 상태입니다.

## 문의 유형으로 찾기

- [[check-expert/문의-대응/faq/index|질문과 답변]] (340건)
- [[check-expert/문의-대응/procedure/index|사용 절차]] (712건)
- [[check-expert/문의-대응/troubleshooting/index|오류 해결]] (119건)
- [[check-expert/문의-대응/caution/index|주의사항]] (23건)
- [[check-expert/문의-대응/tip/index|활용 팁]] (23건)

## 화면별 사례 묶음

- [[check-expert/문의-대응/분류-대기/index|공식 문서에 아직 연결되지 않은 사례]]

- **2,449건** — [[check-expert/문의-대응/화면별/check-excel-manual-함수-설명|함수 설명]]
- **296건** — [[check-expert/문의-대응/화면별/check-excel-manual-메뉴와-템플릿|메뉴와 템플릿]]
- **153건** — [[check-expert/문의-대응/화면별/check-screen-1300|1300 - 주식현재가]]
- **152건** — [[check-expert/문의-대응/화면별/check-screen-4101|4101 - 현재가]]
- **114건** — [[check-expert/문의-대응/화면별/check-screen-8112|8112 - 신종합차트]]
- **99건** — [[check-expert/문의-대응/화면별/check-screen-1440|1440 - ETF 현재가]]
- **84건** — [[check-expert/문의-대응/화면별/check-screen-1448|1448 - ETF 구성종목(PDF)]]
- **80건** — [[check-expert/문의-대응/화면별/check-screen-3471|3471 - 단가계산 > 발행종목]]
- **78건** — [[check-expert/문의-대응/화면별/check-screen-3000|3000 - 발행정보 > 주요 > 종목상세]]
- **58건** — [[check-expert/문의-대응/화면별/check-screen-1443|1443 - ETF 시세표]]
- **48건** — [[check-expert/문의-대응/화면별/check-screen-3774|3774 - 차트 > Yield Spread(추이)]]
- **46건** — [[check-expert/문의-대응/화면별/check-screen-3741|3741 - 시가평가 > 채권그룹 > 기업별 Term Structure]]
- **40건** — [[check-expert/문의-대응/화면별/check-screen-1318|1318 - 시간대별 평균]]
- **39건** — [[check-expert/문의-대응/화면별/check-screen-6106|6106 - 종합]]
- **36건** — [[check-expert/문의-대응/화면별/check-excel-manual-Ez-차트|Ez 차트]]
- **35건** — [[check-expert/문의-대응/화면별/check-screen-3435|3435 - 시가평가 > 채권종목 > 일별추이]]
- **33건** — [[check-expert/문의-대응/화면별/check-screen-4171|4171 - 종목일별]]
- **32건** — [[check-expert/문의-대응/화면별/check-screen-1148|1148 - KRX지수구성정보 서비스(지수구성종목 정보) - 1148]]
- **32건** — [[check-expert/문의-대응/화면별/check-screen-3430|3430 - 시가평가 > 채권그룹 > Matrix 종합]]
- **30건** — [[check-expert/문의-대응/화면별/check-screen-3022|3022 - 발행정보 > 주요 > 종목검색]]
- **29건** — [[check-expert/문의-대응/화면별/check-screen-5103|5103 - 달러-원>일별추이]]
- **26건** — [[check-expert/문의-대응/화면별/check-screen-5100|5100 - 달러-원>종합화면]]
- **22건** — [[check-expert/문의-대응/화면별/check-screen-3005|3005 - 발행정보 > 주요 > 종목별 현금흐름]]
- **22건** — [[check-expert/문의-대응/화면별/check-screen-4501|4501 - 현재가1]]
- **19건** — [[check-expert/문의-대응/화면별/check-screen-3431|3431 - 시가평가 > 채권그룹 > 일별추이]]
- **18건** — [[check-expert/문의-대응/화면별/check-screen-3527|3527 - 차트 > 복수금리 비교2]]
- **18건** — [[check-expert/문의-대응/화면별/check-screen-4114|4114 - 주식선물 시세표]]
- **18건** — [[check-expert/문의-대응/화면별/check-screen-6316|6316 - 경제지표 > (실시간)세계경제지표]]
- **17건** — [[check-expert/문의-대응/화면별/check-screen-3500|3500 - 시장종합 > 투자분석리포트]]
- **17건** — [[check-expert/문의-대응/화면별/check-screen-3743|3743 - 시가평가 > CD/CP > CD/CP 등급별 수익률]]
- **17건** — [[check-expert/문의-대응/화면별/check-screen-4151|4151 - 종목일중]]
- **15건** — [[check-expert/문의-대응/화면별/check-screen-3080|3080 - 장내국채 > 호가(6종목)]]
- **15건** — [[check-expert/문의-대응/화면별/check-screen-4102|4102 - 금리선물]]
- **15건** — [[check-expert/문의-대응/화면별/check-screen-4571|4571 - 종목일별]]
- **15건** — [[check-expert/문의-대응/화면별/check-screen-7000|7000 - 기업종합]]
- **14건** — [[check-expert/문의-대응/화면별/check-screen-1379|1379 - 관심종목 160]]
- **14건** — [[check-expert/문의-대응/화면별/check-screen-1542|1542 - 업종내 구성종목의 상대성과]]
- **14건** — [[check-expert/문의-대응/화면별/check-screen-3026|3026 - 발행정보 > 주요 > DLB(DLS)]]
- **14건** — [[check-expert/문의-대응/화면별/check-screen-4205|4205 - 일중순매수]]
- **14건** — [[check-expert/문의-대응/화면별/check-screen-4511|4511 - 기본시세표]]
- **13건** — [[check-expert/문의-대응/화면별/check-screen-3031|3031 - 발행통계 > 추이]]
- **13건** — [[check-expert/문의-대응/화면별/check-screen-3931|3931 - 해외금리 > 해외국채 국가별]]
- **13건** — [[check-expert/문의-대응/화면별/check-screen-4080|4080 - 선물 KTB이론가]]
- **13건** — [[check-expert/문의-대응/화면별/check-screen-4199|4199 - 과거종목]]
- **13건** — [[check-expert/문의-대응/화면별/check-screen-4338|4338 - 순매수일별]]
- **13건** — [[check-expert/문의-대응/화면별/check-screen-5101|5101 - 달러-원>현재가]]
- **24건** — [[check-expert/문의-대응/화면별/check-screen-1002|1002 - 세계지수종합]]
- **12건** — [[check-expert/문의-대응/화면별/check-screen-3649|3649 - 발행정보 > 주요 > 일별 발행종목]]
- **12건** — [[check-expert/문의-대응/화면별/check-screen-3703|3703 - 유통종합 > 건별 체결]]
- **12건** — [[check-expert/문의-대응/화면별/check-screen-4110|4110 - 투자자현황]]
- **11건** — [[check-expert/문의-대응/화면별/check-screen-1155|1155 - K200 구성종목 등락기여도 - 1155]]
- **11건** — [[check-expert/문의-대응/화면별/check-screen-1370|1370 - 관심종목 평가]]
- **11건** — [[check-expert/문의-대응/화면별/check-screen-3220|3220 - 주요금리 > 최종호가수익률(종합)]]
- **11건** — [[check-expert/문의-대응/화면별/check-screen-3704|3704 - 유통종합 > 종목별 체결]]
- **11건** — [[check-expert/문의-대응/화면별/check-screen-4235|4235 - 일중순매수]]
- **10건** — [[check-expert/문의-대응/화면별/check-screen-1425|1425 - 시간외단일가 시세표]]
- **10건** — [[check-expert/문의-대응/화면별/check-screen-4131|4131 - 체결(실시간)]]
- **10건** — [[check-expert/문의-대응/화면별/check-screen-4203|4203 - 일중추이]]
- **10건** — [[check-expert/문의-대응/화면별/check-screen-4334|4334 - 순매수일중]]
- **9건** — [[check-expert/문의-대응/화면별/check-screen-3210|3210 - 장외(15분체결) > 건별 체결]]
- **9건** — [[check-expert/문의-대응/화면별/check-screen-3805|3805 - 관심채권 > 기본정보 > 시가평가]]
- **9건** — [[check-expert/문의-대응/화면별/check-screen-3924|3924 - 해외금리 > 해외국채 Matrix]]
- **9건** — [[check-expert/문의-대응/화면별/check-screen-4315|4315 - Tick차트]]
- **9건** — [[check-expert/문의-대응/화면별/check-screen-5500|5500 - 해외SPOT>종합화면]]
- **8건** — [[check-expert/문의-대응/화면별/check-screen-2250|2250 - ETN 현재가]]
- **8건** — [[check-expert/문의-대응/화면별/check-screen-3212|3212 - 장외(15분체결) > (장외)투자자별 종목체결]]
- **8건** — [[check-expert/문의-대응/화면별/check-screen-3223|3223 - 주요금리 > 최종호가수익률(추이)]]
- **8건** — [[check-expert/문의-대응/화면별/check-screen-3266|3266 - 투자자 > (장외)종목/투자자 잔고추이]]
- **8건** — [[check-expert/문의-대응/화면별/check-screen-4189|4189 - 일별편집]]
- **7건** — [[check-expert/문의-대응/화면별/check-screen-1147|1147 - KRX지수구성정보 서비스(업종별 지수정보) - 1147]]
- **7건** — [[check-expert/문의-대응/화면별/check-screen-1614|1614 - 회원별 실시간 체결]]
- **7건** — [[check-expert/문의-대응/화면별/check-screen-3011|3011 - 신용등급 > 종합1]]
- **7건** — [[check-expert/문의-대응/화면별/check-screen-3015|3015 - 신용등급 > 발행기관]]
- **7건** — [[check-expert/문의-대응/화면별/check-screen-3016|3016 - 신용등급 > 등급변동현황]]
- **7건** — [[check-expert/문의-대응/화면별/check-screen-3269|3269 - 투자자 > (장외)종류/투자자 실시간 종합]]
- **7건** — [[check-expert/문의-대응/화면별/check-screen-3744|3744 - 시가평가 > CD/CP > CD/CP 등급별 수익률 추이]]
- **7건** — [[check-expert/문의-대응/화면별/check-screen-4109|4109 - 개별주식]]
- **7건** — [[check-expert/문의-대응/화면별/check-screen-4140|4140 - 체결잔량]]
- **7건** — [[check-expert/문의-대응/화면별/check-screen-4242|4242 - 일별순매수]]
- **7건** — [[check-expert/문의-대응/화면별/check-screen-4599|4599 - 과거종목]]
- **7건** — [[check-expert/문의-대응/화면별/check-screen-5722|5722 - 계산기>달러-원 FX SWAP 계산기]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-1149|1149 - KRX지수구성정보 서비스 (지수변동조치(CA) 내역) - 1149]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-1822|1822 - 시장조치내역]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-3045|3045 - 단기자금 > 전단채 > 전자단기사채 발행정보]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-3095|3095 - 차트 > 국채시장]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-3101|3101 - 시장종합 > 국채시장]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-3747|3747 - 시가평가 > CD/CP > CD/CP 개별기업별 수익률]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-3920|3920 - 해외금리 > 미국/일본 국채금리]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-4502|4502 - 현재가2]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-4611|4611 - 일별추이]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-4724|4724 - 과거민감도]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-4733|4733 - 변동성복합차트]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-4754|4754 - 관심전략평가]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-5301|5301 - 고시환율>고시환율 일중추이(외환은행)]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-5303|5303 - 고시환율>매매기준율(서울외국환)]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-6350|6350 - 아시아 지수종합(Tick)]]
- **6건** — [[check-expert/문의-대응/화면별/check-screen-6460|6460 - 글로벌ETF > 시세표]]
- **5건** — [[check-expert/문의-대응/화면별/check-screen-1103|1103 - 지수편집]]
- **5건** — [[check-expert/문의-대응/화면별/check-screen-2251|2251 - ETN 시세표]]
- **5건** — [[check-expert/문의-대응/화면별/check-screen-3065|3065 - 단기자금 > CD/CP > 발행정보(예탁원)]]
- **5건** — [[check-expert/문의-대응/화면별/check-screen-3100|3100 - 시장종합 > 전체시장]]
- **5건** — [[check-expert/문의-대응/화면별/check-screen-3705|3705 - 유통종합 > 주요채권 시세표]]
- **5건** — [[check-expert/문의-대응/화면별/check-screen-4001|4001 - 투자자종합]]
- **5건** — [[check-expert/문의-대응/화면별/check-screen-4106|4106 - 현재가(전종목)]]
- **5건** — [[check-expert/문의-대응/화면별/check-screen-4392|4392 - 일중]]
- **5건** — [[check-expert/문의-대응/화면별/check-screen-4512|4512 - 가격시세표]]
- **5건** — [[check-expert/문의-대응/화면별/check-screen-4581|4581 - 종목일별]]
- **5건** — [[check-expert/문의-대응/화면별/check-screen-5201|5201 - 달러-원 FX스왑>현재가(종합)]]
- **5건** — [[check-expert/문의-대응/화면별/check-screen-5203|5203 - 달러-원 FX스왑>일별추이]]
- **5건** — [[check-expert/문의-대응/화면별/check-screen-6463|6463 - 글로벌ETF > 현재가]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-1547|1547 - 역사적변동성]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-3030|3030 - 발행통계 > 종합]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-3046|3046 - 단기자금 > 전단채 > 전자단기사채 발행통계]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-3275|3275 - 투자자 > 투자자 종합]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-4000|4000 - 선물옵션종합]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-4100|4100 - KOSPI200]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-4193|4193 - 옵션체결]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-4212|4212 - 일별순매수]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-4312|4312 - 차익일중]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-4321|4321 - 일별]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-4322|4322 - 차익일별]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-4331|4331 - 현재가]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-4333|4333 - 투자자일중]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-4503|4503 - Daytrade]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-4531|4531 - 체결(실시간)]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-4551|4551 - 종목일중]]
- **4건** — [[check-expert/문의-대응/화면별/check-screen-4601|4601 - 당일현황]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-1302|1302 - 당일시세예측]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-3047|3047 - 단기자금 > 전단채 > 전자단기사채 만기도래]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-3066|3066 - 단기자금 > CD/CP > CP 발행통계(예탁원)]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-3082|3082 - 장내국채 > 현재가]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-3260|3260 - 투자자 > (장외)종류/투자자 종합]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-3473|3473 - 단가계산 > 단가 범위표(6종목)]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-4034|4034 - 상관계수]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-4192|4192 - 선물체결]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-4204|4204 - 일중비교]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-4211|4211 - 일별추이]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-4213|4213 - 일별비교]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-4311|4311 - 일중]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-4391|4391 - Tick1]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-4574|4574 - 파생거래규모]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-4731|4731 - 역사적변동성]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-5140|5140 - 달러-원>종합화면2]]
- **3건** — [[check-expert/문의-대응/화면별/check-screen-6303|6303 - 미국지수구성종목]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-1339|1339 - 종목(지수) 스프레드]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-1531|1531 - 섹터별 시세분석]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-1623|1623 - 외국계 회원사 실시간매매 종목]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-1928|1928 - 기관외국인합계상세]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-3028|3028 - 발행정보 > 기타 > 상장잔액 변경내역2]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-3037|3037 - 발행통계 > 발행기관별 만기도래(상세)]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-3081|3081 - 장내국채 > 체결]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-3104|3104 - 시장종합 > 채권데일리]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-3113|3113 - 장내일반 > 현재가]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-3136|3136 - 장내소액 > 신고시장가격]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-3211|3211 - 장외(15분체결) > 종목별 체결]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-3250|3250 - 주요금리 > 한화채권수익률(종합)]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-3267|3267 - 투자자 > (장외)종류/투자자 잔고종합]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-3940|3940 - 해외금리 > Markit CDS]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-3960|3960 - 대차거래 > 종합]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4002|4002 - 투자자일중]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4003|4003 - 투자자일별]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4125|4125 - 지수선물 현재가]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4126|4126 - 지수선물 투자자]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4128|4128 - 상품선물투자자]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4217|4217 - 종합순매수]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4313|4313 - 종합일중]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4316|4316 - 일중차트]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4336|4336 - 일별]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4504|4504 - 단일가매매]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4510|4510 - 투자자현황]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4514|4514 - 민감도시세표]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4515|4515 - 투자자시세표]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4519|4519 - 이론가시세표]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4603|4603 - 일중추이]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-4605|4605 - 일중순매수]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-5104|5104 - 달러-원>시간대별]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-5200|5200 - 달러인덱스]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-5304|5304 - 매매기준율 추이(서울외국환)]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-5501|5501 - 해외SPOT>현재가(주요)]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-6300|6300 - 미국지수종합]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-6315|6315 - 세계경제지표]]
- **2건** — [[check-expert/문의-대응/화면별/check-screen-6461|6461 - 글로벌ETF > 성과]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-1160|1160 - 섹터종합]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-1211|1211 - ELW 시세표]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-1340|1340 - 종류주식 스프레드]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-1511|1511 - 제한폭등락/연속등락]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-1584|1584 - 업종구성종목 베타]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-3029|3029 - 발행정보 > 기타 > 이표락 종목검색]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-3032|3032 - 발행통계 > 만기도래]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-3035|3035 - 발행통계 > 발행기관별 종합(상세)]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-3067|3067 - 단기자금 > CD/CP > CP 만기도래(예탁원)]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-3083|3083 - 장내국채 > 시세표]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-3102|3102 - 시장종합 > 주요금리]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-3477|3477 - 단가계산 > 단가 범위표(.5단가)]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-3717|3717 - 유통종합 > 기간별 거래순위]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-3825|3825 - 단가계산 > 1원당 수익률표]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-3921|3921 - 해외금리 > LIBOR/EURIBOR/TIBOR]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4031|4031 - 일중추이]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4033|4033 - 일별추이]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4105|4105 - 현재가(요약)]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4111|4111 - 주식선물 현재가]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4112|4112 - VKOSPI]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4133|4133 - 성향분석]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4134|4134 - 마켓 프로파일]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4141|4141 - 호가잔량]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4201|4201 - 당일현황]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4231|4231 - 당일현황]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4251|4251 - 일중]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4255|4255 - 종목사전공시]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4282|4282 - 일중추이]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4319|4319 - 종합일중차트]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4565|4565 - 대표변동일중]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4610|4610 - 당일비중]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4616|4616 - 종합일별]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4712|4712 - 패리티시세표]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4747|4747 - 만기손익(종합)]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4752|4752 - 실시간이론가]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4783|4783 - 종목일별]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-4791|4791 - Tick]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-5105|5105 - 달러-원>주요환율비교]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-5221|5221 - 이종통화>종합화면]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-6430|6430 - MSCI/FTSE>MSCI 종합]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-6431|6431 - MSCI/FTSE>MSCI 비교]]
- **1건** — [[check-expert/문의-대응/화면별/check-screen-6464|6464 - 글로벌ETF > 구성종목]]

## 관련 화면

- [[check-expert/새로운-모습/종합/1002-1002-세계지수종합|1002 - 세계지수종합]] (mentions_title)
- [[check-expert/새로운-모습/종합/1103-1103-지수편집|1103 - 지수편집]] (mentions_title)
- [[check-expert/새로운-모습/주식/1147-1147-KRX지수구성정보-서비스(업종별-지수정보)-1147|1147 - KRX지수구성정보 서비스(업종별 지수정보) - 1147]] (mentions_title)
- [[check-expert/새로운-모습/주식/1148-1148-KRX지수구성정보-서비스(지수구성종목-정보)-1148|1148 - KRX지수구성정보 서비스(지수구성종목 정보) - 1148]] (mentions_title)
- [[check-expert/새로운-모습/주식/1149-1149-KRX지수구성정보-서비스-(지수변동조치(CA)-내역)-1149|1149 - KRX지수구성정보 서비스 (지수변동조치(CA) 내역) - 1149]] (mentions_title)
- [[check-expert/새로운-모습/주식/1155-1155-K200-구성종목-등락기여도-1155|1155 - K200 구성종목 등락기여도 - 1155]] (mentions_title)
- [[check-expert/새로운-모습/주식/1160-1160-섹터종합|1160 - 섹터종합]] (mentions_title)
- [[check-expert/새로운-모습/ELW/1211-1211-ELW-시세표|1211 - ELW 시세표]] (mentions_title)
- [[check-expert/새로운-모습/주식/1300-1300-주식현재가|1300 - 주식현재가]] (mentions_title)
- [[check-expert/새로운-모습/주식/1302-1302-당일시세예측|1302 - 당일시세예측]] (mentions_title)
- [[check-expert/새로운-모습/주식/1318-1318-시간대별-평균|1318 - 시간대별 평균]] (mentions_title)
- [[check-expert/새로운-모습/주식/1339-1339-종목(지수)-스프레드|1339 - 종목(지수) 스프레드]] (mentions_title)
- [[check-expert/새로운-모습/주식/1340-1340-종류주식-스프레드|1340 - 종류주식 스프레드]] (mentions_title)
- [[check-expert/새로운-모습/관심/1370-1370-관심종목-평가|1370 - 관심종목 평가]] (mentions_title)
- [[check-expert/새로운-모습/관심/1379-1379-관심종목-160|1379 - 관심종목 160]] (mentions_title)
- [[check-expert/새로운-모습/주식/1425-1425-시간외단일가-시세표|1425 - 시간외단일가 시세표]] (mentions_title)
- [[check-expert/새로운-모습/ETP/1440-1440-ETF-현재가|1440 - ETF 현재가]] (mentions_title)
- [[check-expert/새로운-모습/ETP/1443-1443-ETF-시세표|1443 - ETF 시세표]] (mentions_title)
- [[check-expert/새로운-모습/ETP/1448-1448-ETF-구성종목(PDF)|1448 - ETF 구성종목(PDF)]] (mentions_title)
- [[check-expert/새로운-모습/주식/1511-1511-제한폭등락-연속등락|1511 - 제한폭등락/연속등락]] (mentions_title)
- [[check-expert/새로운-모습/주식/1531-1531-섹터별-시세분석|1531 - 섹터별 시세분석]] (mentions_title)
- [[check-expert/새로운-모습/주식/1542-1542-업종내-구성종목의-상대성과|1542 - 업종내 구성종목의 상대성과]] (mentions_title)
- [[check-expert/새로운-모습/주식/1547-1547-역사적변동성|1547 - 역사적변동성]] (mentions_title)
- [[check-expert/새로운-모습/주식/1584-1584-업종구성종목-베타|1584 - 업종구성종목 베타]] (mentions_title)
