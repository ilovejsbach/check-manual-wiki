---
title: 질문과 답변 — 국내 상장 ETF 정보를 엑셀로 추출해 활용 중인데, 해외 상장 ETF도 CHECK에서 같은 방식으로 추출할 수 있는지
  문의…
description: 6460 - 글로벌ETF > 시세표 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 질문과 답변
- 검수 필요
- 6460 - 글로벌ETF > 시세표
source: manual-enrichment.jsonl
knowledge_id: check:support-case:89c3fab8e1302a0f
document_type: support_case
case_type: faq
case_facets:
- faq
case_topic: 6460 - 글로벌ETF > 시세표
case_topics:
- 6460 - 글로벌ETF > 시세표
related_ids:
- check:screen:6460
- check:enrichment:screen:6460
review_status: candidate
mapping_status: mapped
source_locator: 20260916!row:4528
candidate_id: manual-candidate:CRM-04526
---
# 질문과 답변 — 국내 상장 ETF 정보를 엑셀로 추출해 활용 중인데, 해외 상장 ETF도 CHECK에서 같은 방식으로 추출할 수 있는지 문의…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

국내 상장 ETF 정보를 엑셀로 추출해 활용 중인데, 해외 상장 ETF도 CHECK에서 같은 방식으로 추출할 수 있는지 문의했습니다.

## 당시 대응

해외 ETF는 국내 ETF DB와 구성이 달라 현재는 6460 화면에서 엑셀프리미엄 연동 외의 방식으로 바로 엑셀 처리할 수 없습니다. 원하는 형태의 제공은 어려운 상황입니다.

## 연결된 화면·기능

- [[check-expert/새로운-모습/해외/6460-6460-글로벌ETF-시세표|6460 - 글로벌ETF > 시세표]]

## 의미 분류
- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 6460 - 글로벌ETF > 시세표
- 공식 문서 연결: 연결됨
- 증거 위치: `20260916!row:4528`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
