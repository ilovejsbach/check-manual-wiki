---
title: 질문과 답변 — 1542 화면처럼 시총비중 순으로 종목 소팅 및 해당종목의 현재가, 등락률, 거래대금, PER/PBR을 엑셀 [IDENTIF…
description: 1542 - 업종내 구성종목의 상대성과 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 질문과 답변
- 검수 필요
- 1542 - 업종내 구성종목의 상대성과
source: manual-enrichment.jsonl
knowledge_id: check:support-case:09ed5c8a532373f0
document_type: support_case
case_type: faq
case_facets:
- faq
case_topic: 1542 - 업종내 구성종목의 상대성과
case_topics:
- 1542 - 업종내 구성종목의 상대성과
related_ids:
- check:screen:1542
- check:enrichment:screen:1542
review_status: candidate
mapping_status: mapped
source_locator: 20260916!row:3670
candidate_id: manual-candidate:CRM-03668
---
# 질문과 답변 — 1542 화면처럼 시총비중 순으로 종목 소팅 및 해당종목의 현재가, 등락률, 거래대금, PER/PBR을 엑셀 [IDENTIF…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

1542 화면처럼 시총비중 순으로 종목 소팅 및 해당종목의 현재가, 등락률, 거래대금, PER/PBR을 엑셀 [IDENTIFIER] L[REDACTED_ENTITY]로 받아보고 싶습니다. => 에 대한 답변을 [코스피] =CLIST( "", "", -1, "1*002", "[NUMBER]", "", "[NUMBER],[IDENTIFIER],[IDENTIFIER],[NUMBER],[NUMBER]", "DESC", "[IDENTIFIER]=true;") 이렇게 주셨는데 혹시 [REDACTED_ENTITY] 페이퍼에서의 [IDENTIFIER] per 혹은 현재 주가 기준 per 등 다른 per 정보들도 받아볼 수 있을까요?

## 당시 대응

안녕하세요. [IDENTIFIER]+ 입니다. 우선 내부 확인이 필요하여 답변이 늦어져 죄송합니다. [IDENTIFIER] Per의 경우 추가 라이선스 구매가 필요한 부분으로 계약 비용 관련 이슈로 구성 정보를 수신받지 못하고 있습니다. 이점 양해 부탁 드립니다. 감사합니다.

## 연결된 화면·기능

- [[check-expert/새로운-모습/주식/1542-1542-업종내-구성종목의-상대성과|1542 - 업종내 구성종목의 상대성과]]
- [[check-expert/excel-premium/매뉴얼/메뉴와-템플릿|CLIST 함수 설명]]

## 의미 분류
- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 1542 - 업종내 구성종목의 상대성과
- 공식 문서 연결: 연결됨
- 증거 위치: `20260916!row:3670`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
