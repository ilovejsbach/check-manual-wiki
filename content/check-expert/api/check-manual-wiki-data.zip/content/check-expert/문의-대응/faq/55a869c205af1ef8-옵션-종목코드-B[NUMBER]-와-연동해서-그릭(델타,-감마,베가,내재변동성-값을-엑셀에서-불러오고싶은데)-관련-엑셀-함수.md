---
title: 질문과 답변 — 옵션 종목코드 B[NUMBER] 와 연동해서 그릭(델타, 감마,베가,내재변동성 값을 엑셀에서 불러오고싶은데) 관련 엑셀
  함수…
description: 4502 - 현재가2, 4503 - Daytrade, 4504 - 단일가매매 관련 비식별 문의와 당시 대응 기록을 분리한 질문과
  답변 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 질문과 답변
- 검수 필요
- 4502 - 현재가2
- 4503 - Daytrade
- 4504 - 단일가매매
source: manual-enrichment.jsonl
knowledge_id: check:support-case:55a869c205af1ef8
document_type: support_case
case_type: faq
case_facets:
- faq
case_topic: 4502 - 현재가2
case_topics:
- 4502 - 현재가2
- 4503 - Daytrade
- 4504 - 단일가매매
related_ids:
- check:screen:4501
- check:enrichment:screen:4502
- check:enrichment:screen:4503
- check:enrichment:screen:4504
- check:screen:4502
- check:screen:4503
- check:screen:4504
review_status: candidate
mapping_status: mapped
source_locator: CRM데이터(PID복원)!row:874
candidate_id: manual-candidate:VOC-00872
---
# 질문과 답변 — 옵션 종목코드 B[NUMBER] 와 연동해서 그릭(델타, 감마,베가,내재변동성 값을 엑셀에서 불러오고싶은데) 관련 엑셀 함수…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

옵션 종목코드 B[NUMBER] 와 연동해서 그릭(델타, 감마,베가,내재변동성 값을 엑셀에서 불러오고싶은데) 관련 엑셀 함수가 있는지 문의드립니다.

## 당시 대응

안녕하세요. [IDENTIFIER]+ 입니다. 문의주신 'KOSPI 200 콜옵션 2607 992.5' 종목(B[NUMBER])의 그릭값의 경우 아래와 같이 활용하실 수 있으며, TR 4501 현재가1 화면에 나오는 데이터와 동일한 값을 보기 위하여 엑셀 자릿수 늘림이 필요할 수 있습니다. [내재변동성] =CT("B[NUMBER]","4507") [델 타] =CT("B[NUMBER]","4502") [감 마] =CT("B[NUMBER]","4503") [베 가] =CT("B[NUMBER]","4504") 감사합니다.

## 연결된 화면·기능

- [[check-expert/새로운-모습/옵션/4501-4501-현재가1|4501 - 현재가1]]
- [[check-expert/excel-premium/매뉴얼/메뉴와-템플릿|CT 함수 설명]]

## 의미 분류
- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 4502 - 현재가2, 4503 - Daytrade, 4504 - 단일가매매
- 공식 문서 연결: 연결됨
- 증거 위치: `CRM데이터(PID복원)!row:874`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
