---
title: "질문과 답변 — https://[IDENTIFIER].co.kr/ 의 핫 테마 등락률과 1531의 등락률이 다르게 나옵니다. 일중 기준으로…"
description: "1531 - 섹터별 시세분석 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "질문과 답변"
  - "검수 필요"
  - "1531 - 섹터별 시세분석"
source: "manual-enrichment.jsonl"
knowledge_id: "check:support-case:456b5b868e8f74f6"
document_type: "support_case"
case_type: "faq"
case_facets:
  - "faq"
case_topic: "1531 - 섹터별 시세분석"
case_topics:
  - "1531 - 섹터별 시세분석"
related_ids:
  - "check:screen:1531"
  - "check:enrichment:screen:1531"
review_status: "candidate"
mapping_status: "mapped"
source_locator: "20260916!row:5649"
candidate_id: "manual-candidate:CRM-05647"
---
# 질문과 답변 — https://[IDENTIFIER].co.kr/ 의 핫 테마 등락률과 1531의 등락률이 다르게 나옵니다. 일중 기준으로…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

https://[IDENTIFIER].co.kr/ 의 핫 테마 등락률과 1531의 등락률이 다르게 나옵니다. 일중 기준으로 보나, 일별기준일을 당일로 맞추어서 보나 둘다 인포스탁 홈페이지의 등락률과는 상이합니다. 왜 다른지 알고 싶습니다. 1531의 등락률 산출/계산기준도 함께 부탁드리겠습니다. 감사합니다.

## 당시 대응

안녕하세요. [IDENTIFIER]+ 입니다. 네. 내일 다시 유선으로 통화드리겠습니다.

## 의미 분류

- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 1531 - 섹터별 시세분석
- 공식 문서 연결: 연결됨
- 증거 위치: `20260916!row:5649`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
