---
title: 질문과 답변 — 4110 화면의 SP포함순매수 데이터가 체크 API 파생 API에는 SPREAD제외순매수만 제공되어, 향후 추가나 제공
  예정…
description: 4110 - 투자자현황 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 질문과 답변
- 검수 필요
- 4110 - 투자자현황
source: manual-enrichment.jsonl
knowledge_id: check:support-case:86ad48f9d0783b07
document_type: support_case
case_type: faq
case_facets:
- faq
case_topic: 4110 - 투자자현황
case_topics:
- 4110 - 투자자현황
related_ids:
- check:screen:4110
- check:enrichment:screen:4110
review_status: candidate
mapping_status: mapped
source_locator: 비식별 문의 사례
candidate_id: manual-candidate:VOC-00936
---
# 질문과 답변 — 4110 화면의 SP포함순매수 데이터가 체크 API 파생 API에는 SPREAD제외순매수만 제공되어, 향후 추가나 제공 예정…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

4110 화면의 SP포함순매수 데이터가 체크 API 파생 API에는 SPREAD제외순매수만 제공되어, 향후 추가나 제공 예정이 있는지 문의했습니다.

## 당시 대응

해당 요청은 개발 부서에 추가 진행을 요청했으며, 완료되는 대로 추후 연락하겠다고 안내했습니다. 제공 일정은 확정되지 않았습니다.

## 연결된 화면·기능

- [[check-expert/새로운-모습/선물/4110-4110-투자자현황|4110 - 투자자현황]]

## 의미 분류
- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 4110 - 투자자현황
- 공식 문서 연결: 연결됨

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
