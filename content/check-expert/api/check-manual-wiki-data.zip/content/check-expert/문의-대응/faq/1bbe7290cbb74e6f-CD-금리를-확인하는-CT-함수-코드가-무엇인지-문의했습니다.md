---
title: 질문과 답변 — CD 금리를 확인하는 CT 함수 코드가 무엇인지 문의했습니다.
description: 3223 - 주요금리 > 최종호가수익률(추이) 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 질문과 답변
- 검수 필요
- 3223 - 주요금리 > 최종호가수익률(추이)
source: manual-enrichment.jsonl
knowledge_id: check:support-case:1bbe7290cbb74e6f
document_type: support_case
case_type: faq
case_facets:
- faq
case_topic: 3223 - 주요금리 > 최종호가수익률(추이)
case_topics:
- 3223 - 주요금리 > 최종호가수익률(추이)
related_ids:
- check:screen:3223
- check:enrichment:screen:3223
review_status: candidate
mapping_status: mapped
source_locator: 비식별 문의 사례
candidate_id: manual-candidate:VOC-00842
---
# 질문과 답변 — CD 금리를 확인하는 CT 함수 코드가 무엇인지 문의했습니다.

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

CD 금리를 확인하는 CT 함수 코드가 무엇인지 문의했습니다.

## 당시 대응

CD 금리는 =CT( "<값>*097", "<값>") 형태의 CT 함수로 받을 수 있으며, 해당 데이터는 화면번호 3223에서 확인할 수 있다고 안내했습니다.

## 연결된 화면·기능

- [[check-expert/새로운-모습/채권/3223-3223-주요금리-최종호가수익률(추이)|3223 - 주요금리 > 최종호가수익률(추이)]]
- [[check-expert/excel-premium/매뉴얼/메뉴와-템플릿|CT 함수 설명]]

## 의미 분류
- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 3223 - 주요금리 > 최종호가수익률(추이)
- 공식 문서 연결: 연결됨

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
