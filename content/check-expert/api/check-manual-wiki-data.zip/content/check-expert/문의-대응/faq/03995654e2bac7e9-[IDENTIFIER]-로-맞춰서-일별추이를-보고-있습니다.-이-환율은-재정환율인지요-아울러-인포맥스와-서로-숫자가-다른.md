---
title: "질문과 답변 — [IDENTIFIER] 로 맞춰서 일별추이를 보고 있습니다. 이 환율은 재정환율인지요? 아울러 인포맥스와 서로 숫자가 다른…"
description: "5500 - 해외SPOT>종합화면 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "질문과 답변"
  - "검수 필요"
  - "5500 - 해외SPOT>종합화면"
source: "manual-enrichment.jsonl"
knowledge_id: "check:support-case:03995654e2bac7e9"
document_type: "support_case"
case_type: "faq"
case_facets:
  - "faq"
case_topic: "5500 - 해외SPOT>종합화면"
case_topics:
  - "5500 - 해외SPOT>종합화면"
related_ids:
  - "check:screen:5500"
  - "check:enrichment:screen:5500"
review_status: "candidate"
mapping_status: "mapped"
source_locator: "20260916!row:2739"
candidate_id: "manual-candidate:CRM-02737"
---
# 질문과 답변 — [IDENTIFIER] 로 맞춰서 일별추이를 보고 있습니다. 이 환율은 재정환율인지요? 아울러 인포맥스와 서로 숫자가 다른…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

[IDENTIFIER] 로 맞춰서 일별추이를 보고 있습니다. 이 환율은 재정환율인지요? 아울러 인포맥스와 서로 숫자가 다른 이유도 궁금합니다.

## 당시 대응

안녕하세요. JPYKRW 환율은 재정환율이 맞습니다. 해당 환율은 [IDENTIFIER] 데이터로서 입수처가 다를 경우 타 정보단말기와 가격이 다를 수가 있습니다. 감사합니다.

## 의미 분류

- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 5500 - 해외SPOT>종합화면
- 공식 문서 연결: 연결됨
- 증거 위치: `20260916!row:2739`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
