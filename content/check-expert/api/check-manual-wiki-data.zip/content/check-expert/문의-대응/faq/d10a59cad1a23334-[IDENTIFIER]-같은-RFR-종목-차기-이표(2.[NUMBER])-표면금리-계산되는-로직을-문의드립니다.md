---
title: "질문과 답변 — [IDENTIFIER] 같은 RFR 종목 차기 이표(2.[NUMBER]) 표면금리 계산되는 로직을 문의드립니다."
description: "3005 - 발행정보 > 주요 > 종목별 현금흐름 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "질문과 답변"
  - "검수 필요"
  - "3005 - 발행정보 > 주요 > 종목별 현금흐름"
source: "manual-enrichment.jsonl"
knowledge_id: "check:support-case:d10a59cad1a23334"
document_type: "support_case"
case_type: "faq"
case_facets:
  - "faq"
case_topic: "3005 - 발행정보 > 주요 > 종목별 현금흐름"
case_topics:
  - "3005 - 발행정보 > 주요 > 종목별 현금흐름"
related_ids:
  - "check:screen:3005"
  - "check:enrichment:screen:3005"
review_status: "candidate"
mapping_status: "mapped"
source_locator: "20260916!row:3649"
candidate_id: "manual-candidate:CRM-03647"
---
# 질문과 답변 — [IDENTIFIER] 같은 RFR 종목 차기 이표(2.[NUMBER]) 표면금리 계산되는 로직을 문의드립니다.

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

[IDENTIFIER] 같은 RFR 종목 차기 이표(2.[NUMBER]) 표면금리 계산되는 로직을 문의드립니다.

## 당시 대응

안녕하세요. [IDENTIFIER]+ 입니다. 3000번 발행정보화면에서 확인가능하듯이 FRN 기준금리 산정방식에 따라 [IDENTIFIER] [IDENTIFIER] [IDENTIFIER] SHIFT(5영업일) 방식으로 계산됩니다. 상세 내용은 해당 종목의 투자설명서를 참고 부탁드립니다. 계산된 금리와 예탁결제원에 보고된 금리 등을 크로스체크하여 확정합니다. 혹, 표면금리에 이상이 있다고 생각되실 경우 추가 문의 남겨주시면 확인 후 답변드리겠습니다. 감사합니다.

## 의미 분류

- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 3005 - 발행정보 > 주요 > 종목별 현금흐름
- 공식 문서 연결: 연결됨
- 증거 위치: `20260916!row:3649`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
