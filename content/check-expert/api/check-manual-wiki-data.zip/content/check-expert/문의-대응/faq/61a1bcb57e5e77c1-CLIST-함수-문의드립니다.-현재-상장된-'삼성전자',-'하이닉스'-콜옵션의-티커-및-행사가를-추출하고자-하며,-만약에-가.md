---
title: 질문과 답변 — CLIST 함수 문의드립니다. 현재 상장된 '삼성전자', '하이닉스' 콜옵션의 티커 및 행사가를 추출하고자 하며, 만약에
  가…
description: 종목·코드·분류·기본정보 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 질문과 답변
- 검수 필요
- 종목·코드·분류·기본정보
source: manual-enrichment-unmapped.jsonl
knowledge_id: check:support-case:61a1bcb57e5e77c1
document_type: support_case
case_type: faq
case_facets:
- faq
case_topic: 종목·코드·분류·기본정보
case_topics:
- 종목·코드·분류·기본정보
related_ids: []
review_status: candidate
mapping_status: unmapped
source_locator: CRM데이터(PID복원)!row:863
candidate_id: manual-candidate:VOC-00861
---
# 질문과 답변 — CLIST 함수 문의드립니다. 현재 상장된 '삼성전자', '하이닉스' 콜옵션의 티커 및 행사가를 추출하고자 하며, 만약에 가…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

CLIST 함수 문의드립니다. 현재 상장된 '삼성전자', '하이닉스' 콜옵션의 티커 및 행사가를 추출하고자 하며, 만약에 가능하다면, 현재가 기준 OTM 행사가 옵션만 뽑도록 조건을 주는 것도 가능한지 여쭙고 싶습니다. 제가 현재 작성한 함수는 아래와 같습니다. =@CLIST( "", "", -1, "1*012", "⟦[NUMBER]⟧,⟦[NUMBER]⟧", "", "⟦[NUMBER]⟧,⟦[NUMBER]⟧,⟦[NUMBER]⟧,⟦[NUMBER]⟧,⟦[NUMBER]⟧,⟦[NUMBER]⟧", "DESC", "⟦[IDENTIFIER]⟧=true;")

## 당시 대응

안녕하세요. 특정 종목+ 입니다. =CLIST( "", "", -1, "*012", "⟦[NUMBER]⟧", "_⟦[IDENTIFIER]⟧=1191:⟦[NUMBER]⟧,1192:C12", "⟦[NUMBER]⟧,⟦[NUMBER]⟧,⟦[NUMBER]⟧,⟦[NUMBER]⟧", "DESC", "⟦[IDENTIFIER]⟧=true;") 첨부한 CLIST 함수를 가공하시면 원하시는 데이터 추출이 가능할 것 같습니다. 함수 한번 보시고, 사용법 추가 문의 있으시면 전화 부탁드립니다. 감사합니다.

## 연결된 화면·기능

- [[check-expert/excel-premium/매뉴얼/메뉴와-템플릿|CLIST 함수 설명]]

## 의미 분류
- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 종목·코드·분류·기본정보
- 공식 문서 연결: 분류 대기
- 증거 위치: `CRM데이터(PID복원)!row:863`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
