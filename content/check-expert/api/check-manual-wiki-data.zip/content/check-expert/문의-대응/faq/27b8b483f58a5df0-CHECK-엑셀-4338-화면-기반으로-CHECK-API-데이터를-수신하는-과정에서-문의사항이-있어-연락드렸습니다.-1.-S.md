---
title: 질문과 답변 — CHECK 엑셀 4338 화면 기반으로 CHECK API 데이터를 수신하는 과정에서 문의사항이 있어 연락드렸습니다. 1.
  S…
description: 4338 - 순매수일별 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 질문과 답변
- 검수 필요
- 4338 - 순매수일별
source: manual-enrichment.jsonl
knowledge_id: check:support-case:27b8b483f58a5df0
document_type: support_case
case_type: faq
case_facets:
- faq
case_topic: 4338 - 순매수일별
case_topics:
- 4338 - 순매수일별
related_ids:
- check:screen:4338
- check:enrichment:screen:4338
review_status: candidate
mapping_status: mapped
source_locator: 20260916!row:4416
candidate_id: manual-candidate:CRM-04414
---
# 질문과 답변 — CHECK 엑셀 4338 화면 기반으로 CHECK API 데이터를 수신하는 과정에서 문의사항이 있어 연락드렸습니다. 1. S…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

CHECK 엑셀 4338 화면 기반으로 CHECK API 데이터를 수신하는 과정에서 문의사항이 있어 연락드렸습니다. 1. SP 순매수 데이터 단독 제공 여부 - 현재 제공되는 'SP포함 순매수' 및 'SP제외 순매수' 외에 'SP 순매수' 전용 필드/TR을 별도로 제공받을 수 있는지 궁금합니다. 2. 스프레드 종목코드 가공 규칙 - 약정가 수신을 위해 종목코드를 파악 중입니다. (예: MINI K200 스프레드 6869 'D특정 수치S', MINI K200 스프레드 686B 'D특정 수치BS') - API 호출 시 원월물/근월물 조합에 따른 스프레드 종목코드 가공/생성 규칙(Prefix, 월물 표기, Suffix 'S' 붙임 여부 등)에 대한 상세 명세를 요청드립니다.

## 당시 대응

지금 4338 화면에 금액은 실제치고, 수량은 추정치인데 2개 데이터가 다 필요하신 걸까요?

## 연결된 화면·기능

- [[check-expert/새로운-모습/선물/4338-4338-순매수일별|4338 - 순매수일별]]

## 의미 분류
- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 4338 - 순매수일별
- 공식 문서 연결: 연결됨
- 증거 위치: `20260916!row:4416`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
