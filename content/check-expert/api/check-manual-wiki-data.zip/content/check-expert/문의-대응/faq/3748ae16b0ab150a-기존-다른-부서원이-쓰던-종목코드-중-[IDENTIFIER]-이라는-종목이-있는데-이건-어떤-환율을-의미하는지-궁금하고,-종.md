---
title: "질문과 답변 — 기존 다른 부서원이 쓰던 종목코드 중 [IDENTIFIER] 이라는 종목이 있는데 이건 어떤 환율을 의미하는지 궁금하고, 종…"
description: "5103 - 달러-원>일별추이 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "질문과 답변"
  - "검수 필요"
  - "5103 - 달러-원>일별추이"
source: "manual-enrichment.jsonl"
knowledge_id: "check:support-case:3748ae16b0ab150a"
document_type: "support_case"
case_type: "faq"
case_facets:
  - "faq"
case_topic: "5103 - 달러-원>일별추이"
case_topics:
  - "5103 - 달러-원>일별추이"
related_ids:
  - "check:screen:5103"
  - "check:enrichment:screen:5103"
review_status: "candidate"
mapping_status: "mapped"
source_locator: "20260916!row:2631"
candidate_id: "manual-candidate:CRM-02629"
---
# 질문과 답변 — 기존 다른 부서원이 쓰던 종목코드 중 [IDENTIFIER] 이라는 종목이 있는데 이건 어떤 환율을 의미하는지 궁금하고, 종…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

기존 다른 부서원이 쓰던 종목코드 중 [IDENTIFIER] 이라는 종목이 있는데 이건 어떤 환율을 의미하는지 궁금하고, 종목코드에 대해서 통합적으로 검색할 수 있는 화면이 있으면 부탁드립니다.

## 당시 대응

해당 종목은 종가 개념의 원달러 환율[REDACTED_ENTITY], 현재는 사용하지 않는 종목이기에 종목교체를 권장드립니다. 종목코드는 8112 등과 같은 화면에서 검색창을 통해 원하시는 종목을 클릭하셔서 종목코드를 알 수 있습니다. 감사합니다.

## 의미 분류

- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 5103 - 달러-원>일별추이
- 공식 문서 연결: 연결됨
- 증거 위치: `20260916!row:2631`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
