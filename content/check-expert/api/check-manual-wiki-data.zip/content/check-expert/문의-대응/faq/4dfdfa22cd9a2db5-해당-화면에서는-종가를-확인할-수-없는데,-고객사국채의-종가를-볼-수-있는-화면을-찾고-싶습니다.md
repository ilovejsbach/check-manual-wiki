---
title: 질문과 답변 — 해당 화면에서는 종가를 확인할 수 없는데, 고객사국채의 종가를 볼 수 있는 화면을 찾고 싶습니다.
description: 3931 - 해외금리 > 해외국채 국가별 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 질문과 답변
- 검수 필요
- 3931 - 해외금리 > 해외국채 국가별
source: manual-enrichment.jsonl
knowledge_id: check:support-case:4dfdfa22cd9a2db5
document_type: support_case
case_type: faq
case_facets:
- faq
case_topic: 3931 - 해외금리 > 해외국채 국가별
case_topics:
- 3931 - 해외금리 > 해외국채 국가별
related_ids:
- check:enrichment:screen:3931
- check:screen:3931
review_status: candidate
mapping_status: mapped
source_locator: 20260916!row:5440
candidate_id: manual-candidate:CRM-05438
---
# 질문과 답변 — 해당 화면에서는 종가를 확인할 수 없는데, 고객사국채의 종가를 볼 수 있는 화면을 찾고 싶습니다.

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

해당 화면에서는 종가를 확인할 수 없는데, 고객사국채의 종가를 볼 수 있는 화면을 찾고 싶습니다.

## 당시 대응

[3931] 화면에서 하단의 일별 추이 Tab에서는 해당 DATA에 대한 일별 정보를 확인할수 있습니다. 일별 고객사 국채 추이 정보는 [3926] 에서 확인이 가능합니다.

## 연결된 화면·기능

연결 키가 없습니다.

## 의미 분류
- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 3931 - 해외금리 > 해외국채 국가별
- 공식 문서 연결: 연결됨
- 증거 위치: `20260916!row:5440`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
