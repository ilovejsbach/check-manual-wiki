---
title: 질문과 답변 — [REDACTED_ENTITY](DLS)5034 안녕하세요. 금일 공모 발행으로 추정되는 DLB 1종목 Check PC에
  공…
description: 3026 - 발행정보 > 주요 > DLB(DLS) 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 질문과 답변
- 검수 필요
- 3026 - 발행정보 > 주요 > DLB(DLS)
source: manual-enrichment.jsonl
knowledge_id: check:support-case:607c2fdcae30aa78
document_type: support_case
case_type: faq
case_facets:
- faq
case_topic: 3026 - 발행정보 > 주요 > DLB(DLS)
case_topics:
- 3026 - 발행정보 > 주요 > DLB(DLS)
related_ids:
- check:enrichment:screen:3026
- check:screen:3026
review_status: candidate
mapping_status: mapped
source_locator: 20260916!row:4440
candidate_id: manual-candidate:CRM-04438
---
# 질문과 답변 — [REDACTED_ENTITY](DLS)5034 안녕하세요. 금일 공모 발행으로 추정되는 DLB 1종목 Check PC에 공…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

[REDACTED_ENTITY](DLS)5034 안녕하세요. 금일 공모 발행으로 추정되는 DLB 1종목 Check PC에 공시된 내용이 없어, 해당종목 공모/사모 여부 확인 부탁드립니다. 추가로, 지난주 금요일에 발행된 [REDACTED_ENTITY]플랜업(DLB)323 종목은 발행취소 된 것으로 추측되는데 증권발행실적보고서가 보이지 않습니다. 확인 부탁드려도 될까요? 감사합니다.

## 당시 대응

안녕하세요, 말씀주신 종목들의 종목명으로 검색이 어려운데 혹시 KR코드를 알고 계시면 적어주시길 부탁드립니다. 감사합니다.

## 연결된 화면·기능

연결 키가 없습니다.

## 의미 분류
- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 3026 - 발행정보 > 주요 > DLB(DLS)
- 공식 문서 연결: 연결됨
- 증거 위치: `20260916!row:4440`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
