---
title: 질문과 답변 — CHECK 화면을 여러 개 켜 두었더니 종목명을 바꾸려고 검색창을 클릭할 때 몇 초씩 지연되어, 화면을 많이 띄운 탓인지
  문…
description: 4205 - 일중순매수 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 질문과 답변
- 검수 필요
- 4205 - 일중순매수
source: manual-enrichment.jsonl
knowledge_id: check:support-case:3b8ffcbc631cf5b6
document_type: support_case
case_type: faq
case_facets:
- faq
case_topic: 4205 - 일중순매수
case_topics:
- 4205 - 일중순매수
related_ids:
- check:enrichment:screen:4205
- check:screen:4205
review_status: candidate
mapping_status: mapped
source_locator: 비식별 문의 사례
candidate_id: manual-candidate:CRM-04469
---
# 질문과 답변 — CHECK 화면을 여러 개 켜 두었더니 종목명을 바꾸려고 검색창을 클릭할 때 몇 초씩 지연되어, 화면을 많이 띄운 탓인지 문…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

CHECK 화면을 여러 개 켜 두었더니 종목명을 바꾸려고 검색창을 클릭할 때 몇 초씩 지연되어, 화면을 많이 띄운 탓인지 문의했습니다.

## 당시 대응

대응 내용이 기록되지 않았습니다.

## 연결된 화면·기능

연결 키가 없습니다.

## 의미 분류
- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 4205 - 일중순매수
- 공식 문서 연결: 연결됨

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
