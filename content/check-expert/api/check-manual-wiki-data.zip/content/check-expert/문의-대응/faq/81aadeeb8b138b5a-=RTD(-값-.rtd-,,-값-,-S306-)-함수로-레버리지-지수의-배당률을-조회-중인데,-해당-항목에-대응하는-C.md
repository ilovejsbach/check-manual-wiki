---
title: 질문과 답변 — =RTD("<값>.rtd",,"<값>","S306") 함수로 레버리지 지수의 배당률을 조회 중인데, 해당 항목에 대응하는
  C…
description: 기업 재무·배당·컨센서스 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 질문과 답변
- 검수 필요
- 기업 재무·배당·컨센서스
source: manual-enrichment-unmapped.jsonl
knowledge_id: check:support-case:81aadeeb8b138b5a
document_type: support_case
case_type: faq
case_facets:
- faq
case_topic: 기업 재무·배당·컨센서스
case_topics:
- 기업 재무·배당·컨센서스
related_ids: []
review_status: candidate
mapping_status: unmapped
source_locator: 비식별 문의 사례
candidate_id: 81aadeeb8b138b5a
---
# 질문과 답변 — =RTD("<값>.rtd",,"<값>","S306") 함수로 레버리지 지수의 배당률을 조회 중인데, 해당 항목에 대응하는 C…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

=RTD("<값>.rtd",,"<값>","S306") 함수로 레버리지 지수의 배당률을 조회 중인데, 해당 항목에 대응하는 CHECK Expert 단말 화면번호를 문의했습니다.

## 당시 대응

대응 내용이 기록되지 않았습니다.

## 연결된 화면·기능

연결 키가 없습니다.

## 의미 분류
- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 기업 재무·배당·컨센서스
- 공식 문서 연결: 분류 대기

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
