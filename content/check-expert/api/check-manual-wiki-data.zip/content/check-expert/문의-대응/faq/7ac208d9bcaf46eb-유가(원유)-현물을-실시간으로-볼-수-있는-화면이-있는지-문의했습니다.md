---
title: 질문과 답변 — 유가(원유) 현물을 실시간으로 볼 수 있는 화면이 있는지 문의했습니다.
description: 해외 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 질문과 답변
- 검수 필요
- 해외
source: manual-enrichment-unmapped.jsonl
knowledge_id: check:support-case:7ac208d9bcaf46eb
document_type: support_case
case_type: faq
case_facets:
- faq
case_topic: 해외
case_topics:
- 해외
related_ids:
- check:tr:6346
review_status: candidate
mapping_status: unmapped
source_locator: 20260916!row:4791
candidate_id: manual-candidate:CRM-04789
---
# 질문과 답변 — 유가(원유) 현물을 실시간으로 볼 수 있는 화면이 있는지 문의했습니다.

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

유가(원유) 현물을 실시간으로 볼 수 있는 화면이 있는지 문의했습니다.

## 당시 대응

실시간으로 제공하는 화면은 없고, 일별 데이터만 6346 화면에서 확인할 수 있다고 안내했습니다.

## 연결된 화면·기능

- [[check-expert/tr-후보/6346|TR 6346 (화면 문서 없음)]]

## 의미 분류
- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 해외
- 공식 문서 연결: 분류 대기

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
