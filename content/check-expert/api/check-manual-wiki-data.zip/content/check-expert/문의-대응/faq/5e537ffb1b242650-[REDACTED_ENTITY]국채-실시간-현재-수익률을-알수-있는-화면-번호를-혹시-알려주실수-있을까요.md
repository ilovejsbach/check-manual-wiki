---
title: "질문과 답변 — [REDACTED_ENTITY]국채 실시간 현재 수익률을 알수 있는 화면 번호를 혹시 알려주실수 있을까요?"
description: "3924 - 해외금리 > 해외국채 Matrix 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "질문과 답변"
  - "검수 필요"
  - "3924 - 해외금리 > 해외국채 Matrix"
source: "manual-enrichment.jsonl"
knowledge_id: "check:support-case:5e537ffb1b242650"
document_type: "support_case"
case_type: "faq"
case_facets:
  - "faq"
case_topic: "3924 - 해외금리 > 해외국채 Matrix"
case_topics:
  - "3924 - 해외금리 > 해외국채 Matrix"
related_ids:
  - "check:screen:3924"
  - "check:enrichment:screen:3924"
review_status: "candidate"
mapping_status: "mapped"
source_locator: "20260916!row:3639"
candidate_id: "manual-candidate:CRM-03637"
---
# 질문과 답변 — [REDACTED_ENTITY]국채 실시간 현재 수익률을 알수 있는 화면 번호를 혹시 알려주실수 있을까요?

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

[REDACTED_ENTITY]국채 실시간 현재 수익률을 알수 있는 화면 번호를 혹시 알려주실수 있을까요?

## 당시 대응

안녕하세요. [IDENTIFIER]+ 입니다. [REDACTED_ENTITY]국채 수익률의 경우 3930 [REDACTED_ENTITY]국채 시세표 및 3924 [REDACTED_ENTITY]국채 Matrix 등에서 전반적인 시세표를 확인 가능하십니다. 3934 [REDACTED_ENTITY]국채 시간대별 종가 화면에서 특정 국가에 대한 최근 시간대별 추이도 확인 가능하십니다. 감사합니다.

## 의미 분류

- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 3924 - 해외금리 > 해외국채 Matrix
- 공식 문서 연결: 연결됨
- 증거 위치: `20260916!row:3639`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
