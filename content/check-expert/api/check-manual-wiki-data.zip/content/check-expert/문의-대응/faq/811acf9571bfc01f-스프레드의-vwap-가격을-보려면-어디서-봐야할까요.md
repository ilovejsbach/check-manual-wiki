---
title: "질문과 답변 — 스프레드의 vwap 가격을 보려면 어디서 봐야할까요?"
description: "4109 - 개별주식 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "질문과 답변"
  - "검수 필요"
  - "4109 - 개별주식"
source: "manual-enrichment.jsonl"
knowledge_id: "check:support-case:811acf9571bfc01f"
document_type: "support_case"
case_type: "faq"
case_facets:
  - "faq"
case_topic: "4109 - 개별주식"
case_topics:
  - "4109 - 개별주식"
related_ids:
  - "check:screen:4109"
  - "check:enrichment:screen:4109"
review_status: "candidate"
mapping_status: "mapped"
source_locator: "CRM데이터(PID복원)!row:1211"
candidate_id: "manual-candidate:VOC-01209"
---
# 질문과 답변 — 스프레드의 vwap 가격을 보려면 어디서 봐야할까요?

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

스프레드의 vwap 가격을 보려면 어디서 봐야할까요?

## 당시 대응

안녕하세요. [IDENTIFIER]+ 입니다. 스프레드의 VWAP 같은 경우, 엑셀을 통해 확인하시면 좋을 것 같습니다. VWAP(거래량가중평균)의 항목코드는 [NUMBER] 입니다. 예시> SK하이닉스 SP 2602-2603 VWAP =CT("D[NUMBER]S", "[NUMBER]") 도움이 되셨으면 좋겠습니다. 감사합니다.

## 의미 분류

- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 4109 - 개별주식
- 공식 문서 연결: 연결됨
- 증거 위치: `CRM데이터(PID복원)!row:1211`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
