---
title: "질문과 답변 — 채권변동성지수인 MOVE지수는 함수에서 끌고오려면 종목코드를 뭘 써야 할까요? (ICE BofA MOVE Index)"
description: "가격·호가·거래량 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "질문과 답변"
  - "검수 필요"
  - "가격·호가·거래량"
source: "manual-enrichment-unmapped.jsonl"
knowledge_id: "check:support-case:cf364c7d391fdd4a"
document_type: "support_case"
case_type: "faq"
case_facets:
  - "faq"
case_topic: "가격·호가·거래량"
case_topics:
  - "가격·호가·거래량"
related_ids:
  - "check:enrichment:unmapped:078f6cd8e320"
review_status: "candidate"
mapping_status: "unmapped"
source_locator: "CRM데이터(PID복원)!row:828"
candidate_id: "manual-candidate:VOC-00826"
---
# 질문과 답변 — 채권변동성지수인 MOVE지수는 함수에서 끌고오려면 종목코드를 뭘 써야 할까요? (ICE BofA MOVE Index)

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

채권변동성지수인 MOVE지수는 함수에서 끌고오려면 종목코드를 뭘 써야 할까요? (ICE BofA MOVE Index)

## 당시 대응

안녕하세요. [IDENTIFIER]+ 입니다. 유선으로 내용 전달 드렸습니다. 해당 지수의 서비스 여부를 추가로 검토해 보도록 하겠습니다. 감사합니다.

## 의미 분류

- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 가격·호가·거래량
- 공식 문서 연결: 분류 대기
- 증거 위치: `CRM데이터(PID복원)!row:828`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
