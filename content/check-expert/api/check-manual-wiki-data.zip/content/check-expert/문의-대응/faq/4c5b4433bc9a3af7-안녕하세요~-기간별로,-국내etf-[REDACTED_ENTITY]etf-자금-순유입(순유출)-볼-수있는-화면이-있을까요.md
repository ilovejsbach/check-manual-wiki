---
title: 질문과 답변 — 안녕하세요~ 기간별로, 국내etf / [REDACTED_ENTITY]etf 자금 순유입(순유출) 볼 수있는 화면이 있을까요
  ?
description: 6460 - 글로벌ETF > 시세표 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 질문과 답변
- 검수 필요
- 6460 - 글로벌ETF > 시세표
source: manual-enrichment.jsonl
knowledge_id: check:support-case:4c5b4433bc9a3af7
document_type: support_case
case_type: faq
case_facets:
- faq
case_topic: 6460 - 글로벌ETF > 시세표
case_topics:
- 6460 - 글로벌ETF > 시세표
related_ids:
- check:enrichment:screen:6460
- check:screen:6460
review_status: candidate
mapping_status: mapped
source_locator: 20260916!row:6049
candidate_id: manual-candidate:CRM-06047
---
# 질문과 답변 — 안녕하세요~ 기간별로, 국내etf / [REDACTED_ENTITY]etf 자금 순유입(순유출) 볼 수있는 화면이 있을까요 ?

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

안녕하세요~ 기간별로, 국내etf / [REDACTED_ENTITY]etf 자금 순유입(순유출) 볼 수있는 화면이 있을까요 ?

## 당시 대응

국내 : 1446.1447.1457.1453 등 참조하시고 [REDACTED_ENTITY] : 6460 항목설정을 이용, 순자금유입금액 참조하세요

## 연결된 화면·기능

연결 키가 없습니다.

## 의미 분류
- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 6460 - 글로벌ETF > 시세표
- 공식 문서 연결: 연결됨
- 증거 위치: `20260916!row:6049`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
