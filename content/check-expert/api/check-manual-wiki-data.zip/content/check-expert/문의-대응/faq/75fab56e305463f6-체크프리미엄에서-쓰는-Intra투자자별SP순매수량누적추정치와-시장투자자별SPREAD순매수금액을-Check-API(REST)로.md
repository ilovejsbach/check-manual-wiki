---
title: 질문과 답변 — 체크프리미엄에서 쓰는 Intra투자자별SP순매수량누적추정치와 시장투자자별SPREAD순매수금액을 Check API(REST)로…
description: 투자자·회원사 매매·보유 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 질문과 답변
- 검수 필요
- 투자자·회원사 매매·보유
source: manual-enrichment-unmapped.jsonl
knowledge_id: check:support-case:75fab56e305463f6
document_type: support_case
case_type: faq
case_facets:
- faq
case_topic: 투자자·회원사 매매·보유
case_topics:
- 투자자·회원사 매매·보유
related_ids: []
review_status: candidate
mapping_status: unmapped
source_locator: CRM데이터(PID복원)!row:813
candidate_id: manual-candidate:VOC-00811
---
# 질문과 답변 — 체크프리미엄에서 쓰는 Intra투자자별SP순매수량누적추정치와 시장투자자별SPREAD순매수금액을 Check API(REST)로…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

체크프리미엄에서 쓰는 Intra투자자별SP순매수량누적추정치와 시장투자자별SPREAD순매수금액을 Check API(REST)로도 받을 수 있는지 문의했습니다.

## 당시 대응

CHECK API로 수신 가능한 정보 목록은 안내된 홈페이지에서 확인할 수 있습니다. SPREAD순매수 자료는 현재 지원되지 않고, SPREAD제외 순매수 데이터는 가능한 것으로 보입니다.

## 연결된 화면·기능

연결 키가 없습니다.

## 의미 분류
- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 투자자·회원사 매매·보유
- 공식 문서 연결: 분류 대기

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
