---
title: 질문과 답변 — CP와 전단채의 발행기관별 잔존 물량을 확인할 수 있는 화면이 있는지 문의했습니다.
description: 3045 - 단기자금 > 전단채 > 전자단기사채 발행정보, 3065 - 단기자금 > CD/CP > 발행정보(예탁원) 관련 비식별
  문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 질문과 답변
- 검수 필요
- 3045 - 단기자금 > 전단채 > 전자단기사채 발행정보
- 3065 - 단기자금 > CD/CP > 발행정보(예탁원)
source: manual-enrichment.jsonl
knowledge_id: check:support-case:24dc94cbc1346dfb
document_type: support_case
case_type: faq
case_facets:
- faq
case_topic: 3045 - 단기자금 > 전단채 > 전자단기사채 발행정보
case_topics:
- 3045 - 단기자금 > 전단채 > 전자단기사채 발행정보
- 3065 - 단기자금 > CD/CP > 발행정보(예탁원)
related_ids:
- check:screen:3065
- check:enrichment:screen:3045
- check:enrichment:screen:3065
- check:screen:3045
- check:tr:3073
review_status: candidate
mapping_status: mapped
source_locator: 비식별 문의 사례
candidate_id: manual-candidate:CRM-04685
---
# 질문과 답변 — CP와 전단채의 발행기관별 잔존 물량을 확인할 수 있는 화면이 있는지 문의했습니다.

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

CP와 전단채의 발행기관별 잔존 물량을 확인할 수 있는 화면이 있는지 문의했습니다.

## 당시 대응

CP종합통계 3073 화면에서 발행기관별 잔존을 한 번에 볼 수 있습니다. 전단채는 한꺼번에 보는 화면은 없고, 발행기관별 발행물을 전단채 3045, CP 3065 화면에서 확인할 수 있습니다.

## 연결된 화면·기능

- [[check-expert/새로운-모습/채권/3065-3065-단기자금-CD-CP-발행정보(예탁원)|3065 - 단기자금 > CD/CP > 발행정보(예탁원)]]
- [[check-expert/tr-후보/3073|TR 3073 (화면 문서 없음)]]

## 의미 분류
- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 3045 - 단기자금 > 전단채 > 전자단기사채 발행정보, 3065 - 단기자금 > CD/CP > 발행정보(예탁원)
- 공식 문서 연결: 연결됨

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
