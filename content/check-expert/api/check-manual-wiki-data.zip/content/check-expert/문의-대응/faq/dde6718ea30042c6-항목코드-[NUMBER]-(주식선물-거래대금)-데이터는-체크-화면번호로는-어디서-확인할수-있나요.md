---
title: "질문과 답변 — 항목코드 [NUMBER] (주식선물 거래대금) 데이터는 체크 화면번호로는 어디서 확인할수 있나요?"
description: "4171 - 종목일별, 4114 - 주식선물 시세표, 4106 - 현재가(전종목), 4105 - 현재가(요약), 4111 - 주식선물 현재가 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "질문과 답변"
  - "검수 필요"
  - "4171 - 종목일별"
  - "4114 - 주식선물 시세표"
  - "4106 - 현재가(전종목)"
  - "4105 - 현재가(요약)"
  - "4111 - 주식선물 현재가"
source: "manual-enrichment.jsonl"
knowledge_id: "check:support-case:dde6718ea30042c6"
document_type: "support_case"
case_type: "faq"
case_facets:
  - "faq"
case_topic: "4171 - 종목일별"
case_topics:
  - "4171 - 종목일별"
  - "4114 - 주식선물 시세표"
  - "4106 - 현재가(전종목)"
  - "4105 - 현재가(요약)"
  - "4111 - 주식선물 현재가"
related_ids:
  - "check:screen:4171"
  - "check:enrichment:screen:4171"
  - "check:screen:4114"
  - "check:enrichment:screen:4114"
  - "check:screen:4106"
  - "check:enrichment:screen:4106"
  - "check:screen:4105"
  - "check:enrichment:screen:4105"
  - "check:screen:4111"
  - "check:enrichment:screen:4111"
review_status: "candidate"
mapping_status: "mapped"
source_locator: "20260916!row:3413"
candidate_id: "manual-candidate:CRM-03411"
---
# 질문과 답변 — 항목코드 [NUMBER] (주식선물 거래대금) 데이터는 체크 화면번호로는 어디서 확인할수 있나요?

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

항목코드 [NUMBER] (주식선물 거래대금) 데이터는 체크 화면번호로는 어디서 확인할수 있나요?

## 당시 대응

안녕하세요. [IDENTIFIER]+ 입니다. TR 4111 주식선물현재가, 4114 주식선물시세표 계약금액, 거래대금(백만) 으로 표기되어 있습니다. 지수선물, 금리선물 등의 경우에도 4171 선물 일별, 4105 현재가(요약), 4106 현재가(전종목) 등에서 확인하실 수 있습니다. 감사합니다.

## 의미 분류

- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 4171 - 종목일별, 4114 - 주식선물 시세표, 4106 - 현재가(전종목), 4105 - 현재가(요약), 4111 - 주식선물 현재가
- 공식 문서 연결: 연결됨
- 증거 위치: `20260916!row:3413`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
