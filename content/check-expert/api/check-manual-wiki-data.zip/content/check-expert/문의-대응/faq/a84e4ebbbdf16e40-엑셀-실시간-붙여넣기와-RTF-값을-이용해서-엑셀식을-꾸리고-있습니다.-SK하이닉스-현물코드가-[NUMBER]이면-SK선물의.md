---
title: "질문과 답변 — 엑셀 실시간 붙여넣기와 RTF 값을 이용해서 엑셀식을 꾸리고 있습니다. SK하이닉스 현물코드가 [NUMBER]이면 SK선물의…"
description: "4331 - 현재가 관련 비식별 문의와 당시 대응 기록을 분리한 질문과 답변 검수 후보."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "질문과 답변"
  - "검수 필요"
  - "4331 - 현재가"
source: "manual-enrichment.jsonl"
knowledge_id: "check:support-case:a84e4ebbbdf16e40"
document_type: "support_case"
case_type: "faq"
case_facets:
  - "faq"
case_topic: "4331 - 현재가"
case_topics:
  - "4331 - 현재가"
related_ids:
  - "check:screen:4331"
  - "check:enrichment:screen:4331"
review_status: "candidate"
mapping_status: "mapped"
source_locator: "20260916!row:2400"
candidate_id: "manual-candidate:CRM-02398"
---
# 질문과 답변 — 엑셀 실시간 붙여넣기와 RTF 값을 이용해서 엑셀식을 꾸리고 있습니다. SK하이닉스 현물코드가 [NUMBER]이면 SK선물의…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

엑셀 실시간 붙여넣기와 RTF 값을 이용해서 엑셀식을 꾸리고 있습니다. SK하이닉스 현물코드가 [NUMBER]이면 SK선물의 근월물 6월은 [IDENTIFIER]으로도 나오고, 원 코드인 A[NUMBER]으로도 나오는데 7월물의 경우에도 STKFA로 불러지는 다른 코드가 있는지요? 아니면 이 코드는 자동으로 6월물이 만기가 되면 7월로 교체되어서 값을 끌고 가는지 궁금합니다. (근월선물에만 쓰이는 코드)

## 당시 대응

안녕하세요. [IDENTIFIER]+ 입니다. [IDENTIFIER]의 경우 근월물에 해당하는 연결선물 코드 입니다. 말씀 주신대로 6월물 만기 시 7월물로 자동 교체 되는 코드이오니 참고하여 주시기 바랍니다. 감사합니다.

## 의미 분류

- 대표 유형: **질문과 답변**
- 함께 볼 유형: 질문과 답변
- 업무·주제: 4331 - 현재가
- 공식 문서 연결: 연결됨
- 증거 위치: `20260916!row:2400`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
