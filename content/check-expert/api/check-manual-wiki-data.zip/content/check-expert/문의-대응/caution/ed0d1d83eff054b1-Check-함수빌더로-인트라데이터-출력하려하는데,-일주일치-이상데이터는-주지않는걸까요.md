---
title: 주의사항 — Check 함수빌더로 인트라데이터 출력하려하는데, 일주일치 이상데이터는 주지않는걸까요
description: 가격·호가·거래량 관련 비식별 문의와 당시 대응 기록을 분리한 주의사항 검수 후보.
tags:
- CHECK Expert
- 문의 대응
- 주의사항
- 검수 필요
- 가격·호가·거래량
source: manual-enrichment-unmapped.jsonl
knowledge_id: check:support-case:ed0d1d83eff054b1
document_type: support_case
case_type: caution
case_facets:
- caution
case_topic: 가격·호가·거래량
case_topics:
- 가격·호가·거래량
related_ids: []
review_status: candidate
mapping_status: unmapped
source_locator: CRM데이터(PID복원)!row:832
candidate_id: manual-candidate:VOC-00830
---
# 주의사항 — Check 함수빌더로 인트라데이터 출력하려하는데, 일주일치 이상데이터는 주지않는걸까요

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

Check 함수빌더로 인트라데이터 출력하려하는데, 일주일치 이상데이터는 주지않는걸까요

## 당시 대응

인트라 항목마다 차이가 있어 그보다 더 긴 데이터를 쌓고 있는 경우가 있으나 몇 달 이상 장기 데이터를 보시고자 하시는 경우 제한이 있습니다. 보시는 화면 또는 특정 데이터가 있으신지 말씀 부탁 드립니다.

## 연결된 화면·기능

연결 키가 없습니다.

## 의미 분류
- 대표 유형: **주의사항**
- 함께 볼 유형: 주의사항
- 업무·주제: 가격·호가·거래량
- 공식 문서 연결: 분류 대기
- 증거 위치: `CRM데이터(PID복원)!row:832`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
