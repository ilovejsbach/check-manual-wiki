---
title: "주의사항 — 발행사 term [IDENTIFIER] 내용 보고싶은데 3807화면에서 확인가능한가요? 3807화면이 권한이 없다고 나와서…"
description: "3747 - 시가평가 > CD/CP > CD/CP 개별기업별 수익률 관련 비식별 문의와 당시 대응 기록을 분리한 주의사항 검수 후보."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "주의사항"
  - "검수 필요"
  - "3747 - 시가평가 > CD/CP > CD/CP 개별기업별 수익률"
source: "manual-enrichment.jsonl"
knowledge_id: "check:support-case:6e97dc52a949d5e7"
document_type: "support_case"
case_type: "caution"
case_facets:
  - "caution"
  - "faq"
case_topic: "3747 - 시가평가 > CD/CP > CD/CP 개별기업별 수익률"
case_topics:
  - "3747 - 시가평가 > CD/CP > CD/CP 개별기업별 수익률"
related_ids:
  - "check:screen:3747"
  - "check:enrichment:screen:3747"
review_status: "candidate"
mapping_status: "mapped"
source_locator: "20260916!row:4991"
candidate_id: "manual-candidate:CRM-04989"
---
# 주의사항 — 발행사 term [IDENTIFIER] 내용 보고싶은데 3807화면에서 확인가능한가요? 3807화면이 권한이 없다고 나와서…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

발행사 term [IDENTIFIER] 내용 보고싶은데 3807화면에서 확인가능한가요? 3807화면이 권한이 없다고 나와서 문의드립니다.

## 당시 대응

안녕하세요. [IDENTIFIER]+ 입니다. 발행사 Term [IDENTIFIER] 화면은 3741화면을 통해 확인하실 수 있습니다. CD/CP의 경우 3747화면을 통해 확인하실 수 있으니 참고 부탁드립니다. 혹시 화면이 안열리시거나 할 경우, 재문의 부탁드립니다. 감사합니다.

## 의미 분류

- 대표 유형: **주의사항**
- 함께 볼 유형: 주의사항, 질문과 답변
- 업무·주제: 3747 - 시가평가 > CD/CP > CD/CP 개별기업별 수익률
- 공식 문서 연결: 연결됨
- 증거 위치: `20260916!row:4991`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
