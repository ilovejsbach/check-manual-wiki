---
title: "주의사항 — 함수빌더 아래와 같이 했는데 1558화면이랑 대조햇을때 안맞는거 같아요ㅠ 뭐가 문제일까요 CLIST( \"[NUMBER]\",…"
description: "가격·호가·거래량 관련 비식별 문의와 당시 대응 기록을 분리한 주의사항 검수 후보."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "주의사항"
  - "검수 필요"
  - "가격·호가·거래량"
source: "manual-enrichment-unmapped.jsonl"
knowledge_id: "check:support-case:807af5092f13be9e"
document_type: "support_case"
case_type: "caution"
case_facets:
  - "caution"
  - "faq"
case_topic: "가격·호가·거래량"
case_topics:
  - "가격·호가·거래량"
related_ids:
  - "check:enrichment:unmapped:078f6cd8e320"
review_status: "candidate"
mapping_status: "unmapped"
source_locator: "CRM데이터(PID복원)!row:795"
candidate_id: "manual-candidate:VOC-00793"
---
# 주의사항 — 함수빌더 아래와 같이 했는데 1558화면이랑 대조햇을때 안맞는거 같아요ㅠ 뭐가 문제일까요 CLIST( "[NUMBER]",…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

함수빌더 아래와 같이 했는데 1558화면이랑 대조햇을때 안맞는거 같아요ㅠ 뭐가 문제일까요 CLIST( "[NUMBER]", "[NUMBER]", 5, "51*002", "[IDENTIFIER]", "_[IDENTIFIER]=1140:[NUMBER],1141:000", "[IDENTIFIER]", "DESC", "[IDENTIFIER]=true;")

## 당시 대응

안녕하세요. [IDENTIFIER]+ 입니다. 등락률 범위에 제한을 두시려는게 아니면 [IDENTIFIER]에 1141 부분을 제외하셔야 합니다. CLIST( "[NUMBER]", "[NUMBER]", 5, "51*002", "[IDENTIFIER]", "_[IDENTIFIER]=1140:[NUMBER]", "[IDENTIFIER]", "DESC", "[IDENTIFIER]=true;") 혹시 원하시는 데이터가 아니면 필터링 조건에 대한 설명과 함께 다시 한번 문의해주시기 바랍니다. 감사합니다.

## 의미 분류

- 대표 유형: **주의사항**
- 함께 볼 유형: 주의사항, 질문과 답변
- 업무·주제: 가격·호가·거래량
- 공식 문서 연결: 분류 대기
- 증거 위치: `CRM데이터(PID복원)!row:795`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
