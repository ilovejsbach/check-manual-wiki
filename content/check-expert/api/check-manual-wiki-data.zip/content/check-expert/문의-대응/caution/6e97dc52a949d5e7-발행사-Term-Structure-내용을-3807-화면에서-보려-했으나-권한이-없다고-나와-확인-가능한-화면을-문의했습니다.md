---
title: 주의사항 — 발행사 Term Structure 내용을 3807 화면에서 보려 했으나 권한이 없다고 나와 확인 가능한 화면을 문의했습니다.
description: 3747 - 시가평가 > CD/CP > CD/CP 개별기업별 수익률 관련 비식별 문의와 당시 대응 기록을 분리한 주의사항 검수
  후보.
tags:
- CHECK Expert
- 문의 대응
- 주의사항
- 검수 필요
- 3747 - 시가평가 > CD/CP > CD/CP 개별기업별 수익률
source: manual-enrichment.jsonl
knowledge_id: check:support-case:6e97dc52a949d5e7
document_type: support_case
case_type: caution
case_facets:
- caution
- faq
case_topic: 3747 - 시가평가 > CD/CP > CD/CP 개별기업별 수익률
case_topics:
- 3747 - 시가평가 > CD/CP > CD/CP 개별기업별 수익률
related_ids:
- check:screen:3741
- check:screen:3747
- check:enrichment:screen:3747
- check:tr:3807
review_status: candidate
mapping_status: mapped
source_locator: 비식별 문의 사례
candidate_id: 6e97dc52a949d5e7
form_screens:
- '3807'
---
# 주의사항 — 발행사 Term Structure 내용을 3807 화면에서 보려 했으나 권한이 없다고 나와 확인 가능한 화면을 문의했습니다.

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

발행사 Term Structure 내용을 3807 화면에서 보려 했으나 권한이 없다고 나와 확인 가능한 화면을 문의했습니다.

## 당시 대응

발행사 Term Structure 화면은 3741 화면에서 확인할 수 있고, CD/CP는 3747 화면에서 확인할 수 있다고 안내했습니다.

## 연결된 화면·기능

- [[check-expert/새로운-모습/채권/3741-3741-시가평가-채권그룹-기업별-Term-Structure|3741 - 시가평가 > 채권그룹 > 기업별 Term Structure]]
- [[check-expert/새로운-모습/채권/3747-3747-시가평가-CD-CP-CD-CP-개별기업별-수익률|3747 - 시가평가 > CD/CP > CD/CP 개별기업별 수익률]]
- [[check-expert/tr-후보/3807|TR 3807 (화면 문서 없음)]]

## 의미 분류
- 대표 유형: **주의사항**
- 함께 볼 유형: 주의사항, 질문과 답변
- 업무·주제: 3747 - 시가평가 > CD/CP > CD/CP 개별기업별 수익률
- 공식 문서 연결: 연결됨
- 문의 양식의 화면번호 입력값: 3807 (질문 대상 화면과 다를 수 있음)

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
