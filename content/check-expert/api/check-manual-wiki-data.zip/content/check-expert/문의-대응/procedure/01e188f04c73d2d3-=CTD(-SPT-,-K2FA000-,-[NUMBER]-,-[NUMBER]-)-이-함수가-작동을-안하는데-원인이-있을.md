---
title: "사용 절차 — =CTD( \"SPT\", \"K2FA000\", \"[NUMBER]\", \"[NUMBER]\") 이 함수가 작동을 안하는데 원인이 있을…"
description: "조회정보 불명확 관련 비식별 문의와 당시 대응 기록을 분리한 사용 절차 검수 후보."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "사용 절차"
  - "검수 필요"
  - "조회정보 불명확"
source: "manual-enrichment-unmapped.jsonl"
knowledge_id: "check:support-case:01e188f04c73d2d3"
document_type: "support_case"
case_type: "procedure"
case_facets:
  - "procedure"
  - "faq"
case_topic: "조회정보 불명확"
case_topics:
  - "조회정보 불명확"
related_ids:
  - "check:enrichment:unmapped:19fb9193bdf9"
review_status: "candidate"
mapping_status: "unmapped"
source_locator: "CRM데이터(PID복원)!row:776"
candidate_id: "manual-candidate:VOC-00774"
---
# 사용 절차 — =CTD( "SPT", "K2FA000", "[NUMBER]", "[NUMBER]") 이 함수가 작동을 안하는데 원인이 있을…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

=CTD( "SPT", "K2FA000", "[NUMBER]", "[NUMBER]") 이 함수가 작동을 안하는데 원인이 있을까요? 날짜를 당일로 바꾸면 작동합니다.

## 당시 대응

안녕하세요. [IDENTIFIER]+ 입니다. 해당항목코드([NUMBER])는 일별적재되는 데이터가 아닌 관계로 특정일자 조회가 되지 않습니다. * 당일만 조회가능 감사합니다.

## 의미 분류

- 대표 유형: **사용 절차**
- 함께 볼 유형: 사용 절차, 질문과 답변
- 업무·주제: 조회정보 불명확
- 공식 문서 연결: 분류 대기
- 증거 위치: `CRM데이터(PID복원)!row:776`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
