---
title: "사용 절차 — 안녕하세요, 현재 =CLIST(\"\",\"\",-1,A2,\"[NUMBER]\",\"\",\"[NUMBER],[NUMBER],[NUMBER…"
description: "펀드·ETF 구성·운용정보 관련 비식별 문의와 당시 대응 기록을 분리한 사용 절차 검수 후보."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "사용 절차"
  - "검수 필요"
  - "펀드·ETF 구성·운용정보"
source: "manual-enrichment-unmapped.jsonl"
knowledge_id: "check:support-case:06b46b5cd35174bd"
document_type: "support_case"
case_type: "procedure"
case_facets:
  - "procedure"
  - "faq"
case_topic: "펀드·ETF 구성·운용정보"
case_topics:
  - "펀드·ETF 구성·운용정보"
related_ids:
  - "check:enrichment:unmapped:ee6126df39aa"
review_status: "candidate"
mapping_status: "unmapped"
source_locator: "CRM데이터(PID복원)!row:552"
candidate_id: "manual-candidate:VOC-00550"
---
# 사용 절차 — 안녕하세요, 현재 =CLIST("","",-1,A2,"[NUMBER]","","[NUMBER],[NUMBER],[NUMBER…

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

안녕하세요, 현재 =CLIST("","",-1,A2,"[NUMBER]","","[NUMBER],[NUMBER],[NUMBER]","DESC","[IDENTIFIER]=true; [IDENTIFIER]=vert; t[REDACTED_ENTITY]le=none; ") 함수를 이용해서, PDF 구성 종목을 불러오고 있는데 혹시 해당 함수에서 수식을 변경해서 "[NUMBER]" ETF 안에 들어있는 "[NUMBER]" 종목의 수량만을 뽑아내는 함수를 만들 수 있을까요?

## 당시 대응

CLS[REDACTED_ENTITY] 함수에서 필터링기능(함수빌더 참고)을 제공하고 있으나, 모든 항목에대해 적용되지는 않습니다. 말씀하신 PDF구성리스트에 관해서는 적용되지 않고 있습니다. 감사합니다.

## 의미 분류

- 대표 유형: **사용 절차**
- 함께 볼 유형: 사용 절차, 질문과 답변
- 업무·주제: 펀드·ETF 구성·운용정보
- 공식 문서 연결: 분류 대기
- 증거 위치: `CRM데이터(PID복원)!row:552`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
