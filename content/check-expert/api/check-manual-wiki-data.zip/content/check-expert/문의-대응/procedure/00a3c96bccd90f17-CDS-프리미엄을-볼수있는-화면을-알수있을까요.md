---
title: "사용 절차 — CDS 프리미엄을 볼수있는 화면을 알수있을까요"
description: "3940 - 해외금리 > Markit CDS 관련 비식별 문의와 당시 대응 기록을 분리한 사용 절차 검수 후보."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "사용 절차"
  - "검수 필요"
  - "3940 - 해외금리 > Markit CDS"
source: "manual-enrichment.jsonl"
knowledge_id: "check:support-case:00a3c96bccd90f17"
document_type: "support_case"
case_type: "procedure"
case_facets:
  - "procedure"
  - "faq"
case_topic: "3940 - 해외금리 > Markit CDS"
case_topics:
  - "3940 - 해외금리 > Markit CDS"
related_ids:
  - "check:screen:3940"
  - "check:enrichment:screen:3940"
review_status: "candidate"
mapping_status: "mapped"
source_locator: "20260916!row:3691"
candidate_id: "manual-candidate:CRM-03689"
---
# 사용 절차 — CDS 프리미엄을 볼수있는 화면을 알수있을까요

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

CDS 프리미엄을 볼수있는 화면을 알수있을까요

## 당시 대응

안녕하세요. [IDENTIFIER]+ 입니다. 3940화면을 보시면 CDS 프리미엄을 확인하실 수 있습니다. 좌측에 분류에서 국가([IDENTIFIER]), 정부기관([IDENTIFIER]), 금융기관([IDENTIFIER])를 선택하시어 원하시는 국가나 기관을 찾아보실 수 있습니다. 또한 상단의 '전체/관심' 우측의 설정버튼을 눌러보시면, 자주보시는 국가/기관에 대해 관심등록이 가능합니다. 매번 같은 국가/기관을 확인하실 경우, 해당기능 사용을 추천드립니다. 통상적으로 사용하는 CDS 5년만기 프리미엄의 경우, 관심등록 우측에 '5Y만기' 버튼을 눌러서 사용하시는 것을 추천드립니다. 기관 최저, 최고, 평균치를 한눈에 확인하실 수 있습니다. 대외적으로 사용하는 데이터는 [IDENTIFIER] (종가)를 사용하시면 되는데요. 혹시라도 보다 빠른정보를 원하실 경우, [IDENTIFIER] 혹은 [IDENTIFIER]를 이용하시기 바랍니다. [IDENTIFIER] 정보가 모두 업데이트 되고 나면 [IDENTIFIER] 정보가 업데이트 되는 방식이라 보다 더 빠르게 제공됩니다. 감사합니다.

## 의미 분류

- 대표 유형: **사용 절차**
- 함께 볼 유형: 사용 절차, 질문과 답변
- 업무·주제: 3940 - 해외금리 > Markit CDS
- 공식 문서 연결: 연결됨
- 증거 위치: `20260916!row:3691`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
