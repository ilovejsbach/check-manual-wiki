---
title: "사용 절차 — (주관사) 당발 [IDENTIFIER] [REDACTED_ENTITY]49-02이1.5갑-25 발행정보 변경되어 수정요청"
description: "채권 관련 비식별 문의와 당시 대응 기록을 분리한 사용 절차 검수 후보."
tags:
  - "CHECK Expert"
  - "문의 대응"
  - "사용 절차"
  - "검수 필요"
  - "채권"
source: "manual-enrichment-unmapped.jsonl"
knowledge_id: "check:support-case:07ce457dc4a8530c"
document_type: "support_case"
case_type: "procedure"
case_facets:
  - "procedure"
case_topic: "채권"
case_topics:
  - "채권"
related_ids:
  - "check:enrichment:unmapped:11200aac2497"
review_status: "candidate"
mapping_status: "unmapped"
source_locator: "20260916!row:590"
candidate_id: "manual-candidate:CRM-00588"
---
# 사용 절차 — (주관사) 당발 [IDENTIFIER] [REDACTED_ENTITY]49-02이1.5갑-25 발행정보 변경되어 수정요청

> 비식별 문의 기록에서 추출한 검수 전 사례입니다. 당시 대응이 현재 제품의 공식 해결책임을 의미하지 않으며, 공식 매뉴얼과 재현 시험으로 확인해야 합니다.

## 사용자가 겪은 상황

(주관사) 당발 [IDENTIFIER] [REDACTED_ENTITY]49-02이1.5갑-25 발행정보 변경되어 수정요청

## 당시 대응

KRX 표준코드시스템에 이미 수정되어 체크에도 반영된 상태였음. 비상장채권 정보 수정 시 15분 내 반영된다고 설명드림

## 의미 분류

- 대표 유형: **사용 절차**
- 함께 볼 유형: 사용 절차
- 업무·주제: 채권
- 공식 문서 연결: 분류 대기
- 증거 위치: `20260916!row:590`

## 검증할 사항

- [ ] 현재 버전에서도 같은 상황이 재현되는가
- [ ] 당시 대응이 공식 매뉴얼의 절차와 일치하는가
- [ ] 원인과 해결 조치를 구분해 설명할 수 있는가
- [ ] 고객·직원·기관 식별정보가 남아 있지 않은가
